/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package meal;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javafx.beans.InvalidationListener;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.Property;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Label;
import login.User;

/**
 *
 * @author 43699
 */
public final class Meal {

    private final ObjectProperty<Number> ing1 = new SimpleObjectProperty();
    private final ObjectProperty<Number> ing2 = new SimpleObjectProperty();
    private final ObjectProperty<Number> ing3 = new SimpleObjectProperty();
    private final ObjectProperty<Number> ing4 = new SimpleObjectProperty();
    private final ObjectProperty<Number> ing5 = new SimpleObjectProperty();

    private final StringProperty recName = new SimpleStringProperty();

    public Meal() {
        clear();
    }

    public void clear() {
        this.setRecName(null);
        this.setIng1(null);
        this.setIng2(null);
        this.setIng3(null);
        this.setIng4(null);
        this.setIng5(null);

    }

    public Meal(Meal r) {
        this.setIng1(r.getIng1());
        this.setIng2(r.getIng2());
        this.setIng3(r.getIng3());
        this.setIng4(r.getIng4());
        this.setIng5(r.getIng5());

        this.setRecName(r.getRecName());

    }

    public StringProperty recNameProperty() {
        return recName;
    }

    public void setRecName(String value) {
        recName.set(value);
    }

    public String getRecName() {
        return recName.get();
    }

    public ObjectProperty<Number> ing1() {
        return ing1;
    }

    public ObjectProperty<Number> ing2() {
        return ing2;
    }

    public ObjectProperty<Number> ing3() {
        return ing3;
    }

    public ObjectProperty<Number> ing4() {
        return ing4;
    }

    public ObjectProperty<Number> ing5() {
        return ing5;
    }

    public void setIng1(Number value) {
        ing1.set(value);
    }

    public void setIng2(Number value) {
        ing2.set(value);
    }

    public void setIng3(Number value) {
        ing3.set(value);
    }

    public void setIng4(Number value) {
        ing4.set(value);
    }

    public void setIng5(Number value) {
        ing5.set(value);
    }

    public Number getIng1() {
        return ing1.get();
    }

    public Number getIng2() {
        return ing2.get();
    }

    public Number getIng3() {
        return ing3.get();
    }

    public Number getIng4() {
        return ing4.get();
    }

    public Number getIng5() {
        return ing5.get();
    }

    public void save(Statement statement, String name, Label tfMsg2) throws SQLException {
        boolean saveable = true;
        tfMsg2.setText("");
        saveable = killAndFill(tfMsg2);
        if (saveable) {
            String sql = "insert into meal(username, mealname,ing1, ing2, ing3, ing4, ing5)"
                    + "values('" + name + "', '" + recName.get() + "', " + ing1.get() + ", " + ing2.get() + ", " + ing3.get() + ", " + ing4.get()
                    + ", " + ing5.get() + ")";
            statement.executeUpdate(sql);
            tfMsg2.setText("Meal '" + recName.get() + "' was added.");
        } else {
            tfMsg2.setText("Something didnt work");
        }

    }

    private boolean killAndFill(Label tfMsg2) {
        boolean saveable = true;
        // Proteine    
        if (ing1.get() != null
                && (ing1.get().doubleValue() < 1 || ing1.get().doubleValue() > 999)) {
            tfMsg2.setText("The amount of proteins has to be between 1 and 999 ("
                    + ing1.get().doubleValue() + ")!");
            saveable = false;
        } else if (ing1.get() == null) {
            tfMsg2.setText("Please select the amount of proteins.");
            saveable = false;
        }

        // Kohlenhydrate
        if (ing2.get() != null
                && (ing2.get().doubleValue() < 1 || ing2.get().doubleValue() > 999)) {
            tfMsg2.setText("The amount of carbohydrates has to be between 1 and 999 ("
                    + ing2.get().doubleValue() + ")!");
            saveable = false;
        } else if (ing2.get() == null) {
            tfMsg2.setText("Please select the amount of carbohydrates.");
            saveable = false;
        }

        // fett
        if (ing3.get() != null
                && (ing3.get().doubleValue() < 1 || ing3.get().doubleValue() > 999)) {
            tfMsg2.setText("The amount of fat has to be between 1 and 999 ("
                    + ing3.get().doubleValue() + ")!");
            saveable = false;
        } else if (ing3.get() == null) {
            tfMsg2.setText("Please select the amount of fat.");
            saveable = false;
        }

        // zucker
        if (ing4.get() != null
                && (ing4.get().doubleValue() < 1 || ing4.get().doubleValue() > 999)) {
            tfMsg2.setText("The amount of sugar has to be between 1 and 999 ("
                    + ing4.get().doubleValue() + ")!");
            saveable = false;
        } else if (ing4.get() == null) {
            tfMsg2.setText("Please select the amount of sugar.");
            saveable = false;
        }

        // kcal
        if (ing5.get() != null
                && (ing5.get().doubleValue() < 1 || ing5.get().doubleValue() > 9999)) {
            tfMsg2.setText("The amount of kcal has to be between 1 and 9999 ("
                    + ing5.get().doubleValue() + ")!");
            saveable = false;
        } else if (ing5.get() == null) {
            tfMsg2.setText("Please select the amount of kcal.");
            saveable = false;
        }
        return saveable;
    }

    @Override
    public String toString() {
        return "" + recName;
    }

    public static ObservableList<Meal> getAllRecords(Statement statement, String name) throws SQLException {
        String sql = "select mealname from meal where username = '" + name + "'";
        ResultSet rsSet = statement.executeQuery(sql);
        ObservableList<Meal> recList = getRecipeObjects(rsSet);

        return recList;
    }

    public static ObservableList<Meal> getRecipeObjects(ResultSet rsSet) throws SQLException {

        ObservableList<Meal> recList = FXCollections.observableArrayList();

        while (rsSet.next()) {
            Meal r = new Meal();
            r.setRecName(rsSet.getString("mealname"));
            recList.add(r);
        }
        return recList;
    }

}
