package meal;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.NumberFormat;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import login.RegisterC;
import login.User;
import nav.NavC;
import util.NullableNumberStringConverter;

public class MealC {

    @FXML
    private TextField ing1;
    @FXML
    private TextField ing2;
    @FXML
    private TextField ing3;
    @FXML
    private TextField ing4;
    @FXML
    private TextField ing5;
    @FXML
    private TextField recName;
    private TableView recipeView;
    private TableColumn<Meal, String> colName;
    private Button createR;

    private static User currentuser;

    private Statement statement;

    private Meal model;

    private static final NumberFormat DF;

    static {
        DF = NumberFormat.getNumberInstance();
        DF.setMaximumFractionDigits(2);
        DF.setMinimumFractionDigits(2);
    }
    @FXML
    private Button delete;
    @FXML
    private Label tfMsg2;
    @FXML
    private Label tfMsg1;
    @FXML
    private Button goBack;
    @FXML
    private AnchorPane mainAnchorPane;

    public void show(Object u, Statement statement, Stage stage) throws SQLException, Exception {
        try {
            // View
            //  - Root
            FXMLLoader loader = new FXMLLoader(MealC.class.getResource("meal.fxml"));
            Parent root = (Parent) loader.load();

            // - Scene
            Scene scene = new Scene(root);

            // - Stage
            if (stage == null) {
                stage = new Stage();
            }
            stage.setScene(scene);
            stage.setTitle("Meal");

            // Controller
            MealC mealC = (MealC) loader.getController();
            mealC.model = new Meal();
            mealC.statement = statement;

            currentuser = (User) u;
            String name = currentuser.getUsername();
            mealC.getRecName().textProperty().bindBidirectional(mealC.model.recNameProperty());

            mealC.getIng1().textProperty().bindBidirectional(mealC.model.ing1(), new NullableNumberStringConverter(DF));
            mealC.getIng2().textProperty().bindBidirectional(mealC.model.ing2(), new NullableNumberStringConverter(DF));
            mealC.getIng3().textProperty().bindBidirectional(mealC.model.ing3(), new NullableNumberStringConverter(DF));
            mealC.getIng4().textProperty().bindBidirectional(mealC.model.ing4(), new NullableNumberStringConverter(DF));
            mealC.getIng5().textProperty().bindBidirectional(mealC.model.ing5(), new NullableNumberStringConverter(DF));

            mealC.initialize(statement, name);
            stage.show();
        } catch (IOException ex) {
            Logger.getLogger(MealC.class.getName()).log(Level.SEVERE, null, ex);
            System.err.println("Something wrong!");
            ex.printStackTrace(System.err);
            System.exit(1);
        }
    }
    @FXML
    private Button createRecipeButton;
    @FXML
    private ListView<String> recipeList;

    ;
    public TextField getIng1() {
        return ing1;
    }

    public void setIng1(TextField ing1) {
        this.ing1 = ing1;
    }

    public TextField getIng2() {
        return ing2;
    }

    public void setIng2(TextField ing2) {
        this.ing2 = ing2;
    }

    public TextField getIng3() {
        return ing3;
    }

    public void setIng3(TextField ing3) {
        this.ing3 = ing3;
    }

    public TextField getIng4() {
        return ing4;
    }

    public void setIng4(TextField ing4) {
        this.ing4 = ing4;
    }

    public TextField getIng5() {
        return ing5;
    }

    public void setIng5(TextField ing5) {
        this.ing5 = ing5;
    }

    public TextField getRecName() {
        return recName;
    }

    public void setRecName(TextField recName) {
        this.recName = recName;
    }

    public TableView getRecipeView() {
        return recipeView;
    }

    public void setRecipeView(TableView recipeView) {
        this.recipeView = recipeView;
    }

    public TableColumn getColName() {
        return colName;
    }

    public void setColName(TableColumn colName) {
        this.colName = colName;
    }

    public Button getCreateR() {
        return createR;
    }

    public Statement getStatement() {
        return statement;
    }

    @FXML
    private void createRecipe(ActionEvent event) throws SQLException, Exception {

        String name = currentuser.getUsername();
        new Meal(model).save(statement, name, getTfMsg2());
        recipeList.getItems().clear();
        initialize(statement, name);
        recipeList.refresh();

    }

    public void initialize(Statement statement, String name) throws Exception {

        ObservableList<Meal> recList = Meal.getAllRecords(statement, name);

        for (Meal rp : recList) {
            recipeList.getItems().add(rp.getRecName());
        }
    }

    public Label getTfMsg2() {
        return tfMsg2;
    }

    public void setTfMsg2(Label tfMsg2) {
        this.tfMsg2 = tfMsg2;
    }

    public Label getTfMsg1() {
        return tfMsg1;
    }

    public void setTfMsg1(Label tfMsg1) {
        this.tfMsg1 = tfMsg1;
    }

    @FXML
    private void deleteEntry(ActionEvent event) throws SQLException, Exception {
        if (recipeList.getSelectionModel().getSelectedItem() == null) {
            tfMsg1.setText("Please select a meal.");
        } else {
            String mealName = recipeList.getSelectionModel().getSelectedItem();
            String uName = currentuser.getUsername();
            String sql = "delete from meal where username = '" + uName + "' and "
                    + "mealname = '" + mealName + "'";
            statement.executeUpdate(sql);
            tfMsg1.setText("Meal " + mealName + " was deleted");

            recipeList.getItems().clear();
            initialize(statement, uName);
            recipeList.refresh();
        }
    }

    @FXML
    private void goBackToNav(ActionEvent event) {
        NavC nc = new NavC();
        nc.show(currentuser, statement, getStage());
    }

    public Stage getStage() {
        return (Stage) mainAnchorPane.getScene().getWindow();
    }

}
