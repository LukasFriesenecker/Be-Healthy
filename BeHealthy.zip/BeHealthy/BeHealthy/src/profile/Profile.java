/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package profile;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import javafx.scene.chart.XYChart;

/**
 *
 * @author Lukas
 */
public class Profile {

    private ArrayList<Double> data = new ArrayList<>();

    private float avgFats;
    private float avgPro;
    private float avgCal;
    private float avgSugar;
    private float avgCar;

//    public double[] drawGraphs(Statement statement, String search) throws SQLException{  
//        double data[] = new double[5];
//        int i = 0;
//        
//        String getChartData = "SELECT " + search + " FROM valueInputs WHERE userID=1";
//        ResultSet rs = statement.executeQuery(getChartData);
//        
//        while(rs.next()){
//            data[i] = rs.getDouble(search);
//            i++;
//        }
//        
//        return data;
//    }
    public ArrayList drawGraphs(Statement statement, String search, String username) throws SQLException {
        ArrayList<Double> data = new ArrayList<>();

        int id = 0;
        String sqlSelect = "SELECT * FROM users WHERE username='" + username + "'";
        ResultSet rsID = statement.executeQuery(sqlSelect);

        while (rsID.next()) {
            id = rsID.getInt("userID");
        }
        rsID.close();

        String getChartData = "SELECT " + search + " FROM valueInputs WHERE userID=" + id;
        ResultSet rs = statement.executeQuery(getChartData);

        while (rs.next()) {
            data.add(rs.getDouble(search));
        }

        rs.close();
        return data;
    }

    public ArrayList getDate(Statement statement, String username) throws SQLException {
        ArrayList<Timestamp> date = new ArrayList<>();

        int id = 0;
        String sqlSelect = "SELECT * FROM users WHERE username='" + username + "'";
        ResultSet rsID = statement.executeQuery(sqlSelect);

        while (rsID.next()) {
            id = rsID.getInt("userID");
        }
        rsID.close();

        String getChartData = "SELECT currentTimestamp FROM valueInputs WHERE userID=" + id;
        ResultSet rs = statement.executeQuery(getChartData);

        while (rs.next()) {
            date.add(rs.getTimestamp("currentTimestamp"));
        }

        rs.close();
        return date;
    }

    public void getAvg(Statement statement) throws SQLException {
        String getAvg = "SELECT avg(fett), avg(proteine), avg(kohlenhydrate), avg(zucker), avg(kcal) FROM valueInputs WHERE userID=1";
        ResultSet rs = statement.executeQuery(getAvg);

        if (rs.next()) {
            setAvgFats(rs.getFloat(1));
            setAvgPro(rs.getFloat(2));
            setAvgCar(rs.getFloat(3));
            setAvgSugar(rs.getFloat(4));
            setAvgCal(rs.getFloat(5));
        }
    }

    public float getAvgFats() {
        return avgFats;
    }

    public void setAvgFats(float avgFats) {
        this.avgFats = avgFats;
    }

    public float getAvgPro() {
        return avgPro;
    }

    public void setAvgPro(float avgPro) {
        this.avgPro = avgPro;
    }

    public float getAvgCal() {
        return avgCal;
    }

    public void setAvgCal(float avgCal) {
        this.avgCal = avgCal;
    }

    public float getAvgSugar() {
        return avgSugar;
    }

    public void setAvgSugar(float avgSugar) {
        this.avgSugar = avgSugar;
    }

    public float getAvgCar() {
        return avgCar;
    }

    public void setAvgCar(float avgCar) {
        this.avgCar = avgCar;
    }
}
