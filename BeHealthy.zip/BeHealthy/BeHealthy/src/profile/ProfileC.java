/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package profile;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.ResourceBundle;
import java.util.function.Consumer;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import login.LoginC;
import login.RegisterC;
import login.User;
import nav.NavC;
import weight.WeightC;

/**
 * FXML Controller class
 *
 * @author Lukas
 */
public class ProfileC {

    @FXML
    private AnchorPane mainAnchorPane;

    @FXML
    private Button goBack;

    @FXML
    private Label usernameLabel;
    @FXML
    private Label heightLabel;
    @FXML
    private Label weightLabel;
    @FXML
    private Label ageLabel;

    @FXML
    private NumberAxis y;
    @FXML
    private CategoryAxis x;
    @FXML
    private LineChart<?, ?> lineGraph;

    @FXML
    private Label avgCal;
    @FXML
    private Label avgPro;
    @FXML
    private Label avgFats;
    @FXML
    private Label avgSugar;
    @FXML
    private Label avgCar;
    @FXML
    private CheckBox fatsCheckBox;
    @FXML
    private CheckBox calCheckBox;
    @FXML
    private CheckBox proCheckBox;
    @FXML
    private CheckBox sugarCheckBox;
    @FXML
    private CheckBox carCheckBox;

    public Statement statement;

    private static User user;
    private static Profile profile;

    private String[] lineID = new String[5];
    @FXML
    private Button logOutButton;
    @FXML
    private Button weightBtn;

    public void show(Object object, Statement statement, Stage stage) {
        try {
            // View
            //  - Root

            FXMLLoader loader = new FXMLLoader(ProfileC.class.getResource("Profile.fxml"));

            Parent root = (Parent) loader.load();

            // - Scene
            Scene scene = new Scene(root);

            // - Stage
            if (stage == null) {
                stage = new Stage();
            }
            stage.setScene(scene);
            stage.setTitle("Profile");

            // Controller
            ProfileC valueC = (ProfileC) loader.getController();
            valueC.statement = statement;

            user = (User) object;
            profile = new Profile();

            valueC.init();

            stage.show();
        } catch (IOException ex) {
            Logger.getLogger(RegisterC.class.getName()).log(Level.SEVERE, null, ex);
            System.err.println("Something wrong");
            ex.printStackTrace(System.err);
            System.exit(1);
        }
    }

    @FXML
    private void goBackToNav(ActionEvent event) {
        NavC nc = new NavC();
        nc.show(user, statement, getStage());
    }

    public Stage getStage() {
        return (Stage) mainAnchorPane.getScene().getWindow();
    }

    public void init() {
        try {
            String age = String.format("%.0f", user.getAge());

            usernameLabel.setText(user.getUsername());
            heightLabel.setText("" + user.getHeight());
            weightLabel.setText("" + user.getWeight());
            ageLabel.setText("AGE: " + age);

            profile.getAvg(statement);

            avgCal.setText("" + profile.getAvgCal());
            avgPro.setText("" + profile.getAvgPro());
            avgFats.setText("" + profile.getAvgFats());
            avgSugar.setText("" + profile.getAvgSugar());
            avgCar.setText("" + profile.getAvgCar());

            Arrays.fill(lineID, "");
        } catch (SQLException ex) {
            Logger.getLogger(ProfileC.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void drawGraph(CheckBox box, String search) {
        XYChart.Series series = new XYChart.Series();
        ArrayList<Double> data;
        ArrayList<Timestamp> date;
        boolean setDown = false;

        try {
            if (box.isSelected()) {
                for (int x = 0; x < 5; x++) {
                    if (lineID[x] == "") {
                        lineID[x] = search;
                        x = 5;
                    }
                }

                data = profile.drawGraphs(statement, search, user.getUsername());
                date = profile.getDate(statement, user.getUsername());

                for (int i = 0; i < data.size(); i++) {
                    String dateString = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss").format(date.get(i));
                    series.getData().add(new XYChart.Data(dateString, data.get(i)));
                }

                lineGraph.getData().addAll(series);
            } else {
                for (int x = 0; x < 5; x++) {
                    if (lineID[x] == search) {
                        lineGraph.getData().remove(x);
                        lineID[x] = "";
                        setDown = true;
                    }

                    if (setDown && lineID[x] != "") {
                        for (int y = x - 1; y < 4; y++) {
                            lineID[y] = lineID[y + 1];
                            x = 5;
                            setDown = false;
                        }
                    }
                }
            }

            /*for (int x = 0; x < 5; x++) {
                System.out.print(lineID[x] + " - ");
            }

            System.out.println("");*/
        } catch (SQLException ex) {
            Logger.getLogger(ProfileC.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void loadFatsGraph(ActionEvent event) {
        drawGraph(fatsCheckBox, "fett");
    }

    @FXML
    private void loadCalGraph(ActionEvent event) {
        drawGraph(calCheckBox, "kcal");
    }

    @FXML
    private void loadProGraph(ActionEvent event) {
        drawGraph(proCheckBox, "proteine");
    }

    @FXML
    private void loadSugarGraph(ActionEvent event) {
        drawGraph(sugarCheckBox, "zucker");
    }

    @FXML
    private void loadCarGraph(ActionEvent event) {
        drawGraph(carCheckBox, "kohlenhydrate");
    }

    @FXML
    private void logOut(ActionEvent event) {
        user.clear();
        LoginC lc = new LoginC();
        lc.show(null, statement, getStage());
         Stage stage = (Stage) logOutButton.getScene().getWindow();
        stage.close();
    }

    @FXML
    private void goToWeight(ActionEvent event) throws SQLException {
        WeightC wC = new WeightC();
        wC.show(user, statement, getStage());
    }
}
