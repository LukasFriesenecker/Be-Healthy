/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package todayValues;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import login.RegisterC;
import login.User;
import nav.NavC;
import profile.Profile;
import profile.ProfileC;

/**
 * FXML Controller class
 *
 * @author Tobias
 */
public class PieChartController {

    @FXML
    private PieChart pieChart;
    private Statement statement;
    @FXML
    private Label headline;
    private int proteine = 0;
    private int kohlenhydrate = 0;
    private int fett = 0;
    private int zucker = 0;
    private int kcal = 0;
    @FXML
    private Button goBack;
    
    private static User user;
    @FXML
    private AnchorPane mainAnchorPane;
    @FXML
    private Label tfCarbonhydrates;
    @FXML
    private Label tfFat;
    @FXML
    private Label tfProteins;
    @FXML
    private Label tfSugar;
    @FXML
    private Label tfKcal;

    /**
     * Initializes the controller class.
     */
    public void init(Object object, Statement statement) throws SQLException {
        User u = (User) object;
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        timestamp.setMinutes(0);
        timestamp.setHours(0);
        timestamp.setNanos(0);
        timestamp.setSeconds(0);
        int id = 0;
        String sqlSelect = "SELECT * FROM users WHERE username='" + u.getUsername() + "'";
        ResultSet rs = statement.executeQuery(sqlSelect);

        while (rs.next()) {
            id = rs.getInt("userID");
        }

        // Get data
        String sql_proteine = "SELECT proteine FROM valueInputs where userID = " + id + "AND currentDay=" + "'" + timestamp + "'";
        rs = statement.executeQuery(sql_proteine);

        while (rs.next()) {
            proteine += rs.getDouble("proteine");
        }
    
        tfProteins.setText(tfProteins.getText()+ " " + proteine + "g");

        String sql_kohlenhydrate = "SELECT kohlenhydrate FROM valueInputs where userID = " + id + "AND currentDay=" + "'" + timestamp + "'";
        rs = statement.executeQuery(sql_kohlenhydrate);

        while (rs.next()) {
            kohlenhydrate += rs.getDouble("kohlenhydrate");
        }
        tfCarbonhydrates.setText(tfCarbonhydrates.getText()+ " " + kohlenhydrate + "g");

        String sql_fett = "SELECT fett FROM valueInputs where userID = " + id + "AND currentDay=" + "'" + timestamp + "'";
        rs = statement.executeQuery(sql_fett);

        while (rs.next()) {
            fett += rs.getDouble("fett");
        }
        tfFat.setText(tfFat.getText()+ " " + fett + "g");

        String sql_zucker = "SELECT zucker FROM valueInputs where userID = " + id + "AND currentDay=" + "'" + timestamp + "'";
        rs = statement.executeQuery(sql_zucker);

        while (rs.next()) {
            zucker += rs.getDouble("zucker");
        }
        tfSugar.setText(tfSugar.getText()+ " " + zucker + "g");

        String sql_kcal = "SELECT kcal FROM valueInputs where userID = " + id + "AND currentDay=" + "'" + timestamp + "'";
        rs = statement.executeQuery(sql_kcal);

        while (rs.next()) {
            kcal += rs.getDouble("kcal");
        }
        tfKcal.setText(tfKcal.getText()+ " " + kcal + "kcal");

        // Set data
        ObservableList<PieChart.Data> pieChartData
                = FXCollections.observableArrayList();
        if (proteine != 0) {
            pieChartData.add(new PieChart.Data("Proteins", proteine));
        }
        if (kohlenhydrate != 0) {
            pieChartData.add(new PieChart.Data("Carbonhydrates", kohlenhydrate));
        }
        if (fett != 0) {
            pieChartData.add(new PieChart.Data("Fat", fett));
        }
        if (zucker != 0) {
            pieChartData.add(new PieChart.Data("Sugar", zucker));
        }
        if (kcal != 0) {
            pieChartData.add(new PieChart.Data("Calories", kcal));
        }

        if (pieChartData.isEmpty()) {
            pieChartData.add(new PieChart.Data("You didnt eat anything today.", 100.0));
        }

        pieChart.setData(pieChartData);

        headline.setText(u.getUsername());
    }

    public void show(Object object, Statement statement, Stage stage) throws SQLException {
        try {
            // View
            //  - Root

            FXMLLoader loader = new FXMLLoader(PieChartController.class.getResource("PieChart.fxml"));

            Parent root = (Parent) loader.load();

            // - Scene
            Scene scene = new Scene(root);
            scene.getStylesheets().add("/CSS/pieChart.css");

            // - Stage
            if (stage == null) {
                stage = new Stage();
            }
            stage.setScene(scene);
            stage.setTitle("My daily values");

            // Controller
            PieChartController pcC = (PieChartController) loader.getController();
            pcC.statement = statement;
            
            user = (User) object;

            pcC.init(object, statement);

            stage.show();
        } catch (IOException ex) {
            Logger.getLogger(RegisterC.class.getName()).log(Level.SEVERE, null, ex);
            System.err.println("Something wrong");
            ex.printStackTrace(System.err);
            System.exit(1);
        }
    }

    @FXML
    private void goBackToNav(ActionEvent event) {
        NavC nc = new NavC();
        nc.show(user, statement, getStage());
    }
    
        public Stage getStage() {
        return (Stage) mainAnchorPane.getScene().getWindow();
    }

}
