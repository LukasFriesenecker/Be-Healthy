package weight;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import login.RegisterC;
import login.User;
import nav.NavC;
import profile.Profile;
import profile.ProfileC;

public class WeightC {

    private static User user;
    private Statement statement;
    private static Weight weight;

    private ObservableList<String> options = FXCollections.observableArrayList("LOSE WEIGHT", "KEEP WEIGHT", "GAIN WEIGHT");

    private String[][] tipps;
    private int arrayIndex = 0;

    @FXML
    private AnchorPane mainAnchorPane;
    @FXML
    private Button goBack;
    @FXML
    private TextField tfWeight;
    @FXML
    private LineChart<?, ?> weightChart;
    @FXML
    private NumberAxis y;
    @FXML
    private CategoryAxis x;
    @FXML
    private Label headline;
    @FXML
    private ChoiceBox tippType;
    @FXML
    private TextField tippName;
    @FXML
    private TextArea tippDesc;
    @FXML
    private Button createButton;
    @FXML
    private Button previousBtn;
    @FXML
    private Button nextBtn;
    @FXML
    private Label nameOutput;
    @FXML
    private Label userOutput;
    @FXML
    private Label descOutput;

    public void show(Object object, Statement statement, Stage stage) throws SQLException {
        try {
            // View
            //  - Root

            FXMLLoader loader = new FXMLLoader(WeightC.class.getResource("WeightV.fxml"));

            Parent root = (Parent) loader.load();

            // - Scene
            Scene scene = new Scene(root);

            // - Stage
            if (stage == null) {
                stage = new Stage();
            }
            stage.setScene(scene);
            stage.setTitle("My weight");

            // Controller
            WeightC weightC = (WeightC) loader.getController();
            weightC.statement = statement;

            user = (User) object;
            weight = new Weight();

            weightC.init();
            weightC.drawGraph();

            weightC.tippType.setValue("LOSE WEIGHT");
            weightC.tippType.setItems(options);

            stage.show();
        } catch (IOException ex) {
            Logger.getLogger(RegisterC.class.getName()).log(Level.SEVERE, null, ex);
            System.err.println("Something wrong");
            ex.printStackTrace(System.err);
            System.exit(1);
        }
    }

    @FXML
    private void goBackToNav(ActionEvent event) {
        NavC nc = new NavC();
        nc.show(user, statement, getStage());
    }

    public Stage getStage() {
        return (Stage) mainAnchorPane.getScene().getWindow();
    }

    public TextField getTfWeight() {
        return tfWeight;
    }

    public void setTfWeight(TextField tfWeight) {
        this.tfWeight = tfWeight;
    }

    public void init() throws SQLException {
        String aim = weight.getAim(statement, user.getUsername());

        switch (aim) {
            case "L":
                headline.setText("TIPPS TO LOSE WEIGHT");
                tipps = weight.getTipps(statement, "LOSE WEIGHT");
                setTippValues();
                break;

            case "K":
                headline.setText("TIPPS TO KEEP WEIGHT");
                tipps = weight.getTipps(statement, "KEEP WEIGHT");
                setTippValues();
                break;

            case "G":
                headline.setText("TIPPS TO GAIN WEIGHT");
                tipps = weight.getTipps(statement, "GAIN WEIGHT");
                setTippValues();
                break;
        }
    }

    @FXML
    private void enterWeight(ActionEvent event) throws SQLException {
        weight.enterWeight(tfWeight.getText(), statement, user.getUsername());
        tfWeight.setText("");
        drawGraph();
    }

    public void drawGraph() throws SQLException {
        ArrayList<Double> data;
        ArrayList<Timestamp> date;

        XYChart.Series series = new XYChart.Series();

        data = weight.drawGraphs(statement, user.getUsername());
        date = weight.getDate(statement, user.getUsername());

        for (int i = 0; i < data.size(); i++) {
            String dateString = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss").format(date.get(i));
            series.getData().add(new XYChart.Data(dateString, data.get(i)));
        }

        weightChart.getData().addAll(series);
    }

    @FXML
    private void createTipp(ActionEvent event) throws SQLException, InterruptedException {
        weight.createTipp(statement, user.getUsername(), tippName.getText(), (String) tippType.getValue(), tippDesc.getText());
        tippName.setText("");
        tippType.setValue("LOSE WEIGHT");
        tippDesc.setText("");
        init();
    }

    @FXML
    private void getPrevious(ActionEvent event) throws SQLException {
        if (0 <= arrayIndex - 1) {
            arrayIndex--;
            setTippValues();

        }
    }

    @FXML
    private void getNext(ActionEvent event) throws SQLException {
        if (tipps.length - 1 >= arrayIndex + 1) {
            arrayIndex++;
            setTippValues();
        }
    }

    public void setTippValues() {
        if (tipps != null && tipps.length > 0) {
            userOutput.setText("by " + tipps[arrayIndex][0]);
            nameOutput.setText(tipps[arrayIndex][1]);
            descOutput.setText(tipps[arrayIndex][3]);
        }
    }
}
