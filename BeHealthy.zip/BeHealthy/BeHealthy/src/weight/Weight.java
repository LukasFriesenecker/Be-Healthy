package weight;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;

public class Weight {

    public void enterWeight(String weight, Statement statement, String username) throws SQLException {
        int id = 0;
        String sqlSelect = "SELECT * FROM users WHERE username='" + username + "'";
        ResultSet rsID = statement.executeQuery(sqlSelect);

        while (rsID.next()) {
            id = rsID.getInt("userID");
        }
        rsID.close();

        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        String enterWeight = "INSERT INTO weight(userID, weight, currentTimeStamp) VALUES(" + id + ", " + weight + ", '" + timestamp + "')";
        statement.executeUpdate(enterWeight);

        String updateUser = "UPDATE users SET weight=" + weight + " WHERE userID=" + id;
        statement.executeUpdate(updateUser);
    }

    public ArrayList drawGraphs(Statement statement, String username) throws SQLException {
        ArrayList<Double> data = new ArrayList<>();

        int id = 0;
        String sqlSelect = "SELECT * FROM users WHERE username='" + username + "'";
        ResultSet rsID = statement.executeQuery(sqlSelect);

        while (rsID.next()) {
            id = rsID.getInt("userID");
        }
        rsID.close();

        String getChartData = "SELECT * FROM weight WHERE userID=" + id;
        ResultSet rs = statement.executeQuery(getChartData);

        while (rs.next()) {
            data.add(rs.getDouble("weight"));
        }

        rs.close();
        return data;
    }

    public ArrayList getDate(Statement statement, String username) throws SQLException {
        ArrayList<Timestamp> date = new ArrayList<>();

        int id = 0;
        String sqlSelect = "SELECT * FROM users WHERE username='" + username + "'";
        ResultSet rsID = statement.executeQuery(sqlSelect);

        while (rsID.next()) {
            id = rsID.getInt("userID");
        }
        rsID.close();

        String getChartData = "SELECT currentTimestamp FROM weight WHERE userID=" + id;
        ResultSet rs = statement.executeQuery(getChartData);

        while (rs.next()) {
            date.add(rs.getTimestamp("currentTimeStamp"));
        }

        rs.close();
        return date;
    }

    public String getAim(Statement statement, String username) throws SQLException {
        int id = 0;
        String aim = "";

        String sqlSelect = "SELECT * FROM users WHERE username='" + username + "'";
        ResultSet rsID = statement.executeQuery(sqlSelect);

        while (rsID.next()) {
            id = rsID.getInt("userID");
        }
        rsID.close();

        String getAim = "SELECT weightaim FROM users WHERE userID=" + id + "";
        ResultSet rsAim = statement.executeQuery(getAim);

        while (rsAim.next()) {
            aim = rsAim.getString("weightaim");
        }
        rsAim.close();

        return aim;
    }

    void createTipp(Statement statement, String username, String name, String type, String desc) throws SQLException {
        String createTipp = "INSERT INTO tipps(username, name, type, description) VALUES('" + username + "', '" + name + "', '" + type + "', '" + desc + "')";
        statement.executeUpdate(createTipp);
    }

    public String[][] getTipps(Statement statement, String filter) throws SQLException {
        int i = 0;
        int size = 0;
        String[][] tipps = null;

        String getTipps = "SELECT * FROM tipps WHERE type='" + filter + "'";
        ResultSet rsSize = statement.executeQuery(getTipps);

        while (rsSize.next()) {
            size++;
        }

        rsSize.close();

        tipps = new String[size][4];

        ResultSet rs = statement.executeQuery(getTipps);

        while (rs.next()) {
            tipps[i][0] = rs.getString("username");
            tipps[i][1] = rs.getString("name");
            tipps[i][2] = rs.getString("type");
            tipps[i][3] = rs.getString("description");
            i++;
        }

        rs.close();

        return tipps;
    }
}
