/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nav;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import login.LoginC;
import login.RegisterC;
import login.User;
import meal.MealC;
import perMealValues.ViewController;
import profile.ProfileC;
import todayValues.PieChartController;
import weight.WeightC;

/**
 * FXML Controller class
 *
 * @author Tobias
 */
public class NavC {

    @FXML
    private ImageView imgView;
    @FXML
    private Button btn1;
    @FXML
    private Button btn2;
    @FXML
    private Button btn3;
    @FXML
    private Button btn4;
    private Statement statement;
    private static User user;

    @FXML
    private AnchorPane mainAnchorPane;

    public void show(Object object, Statement statement, Stage stage) {
        try {
            // View
            //  - Root
            FXMLLoader loader = new FXMLLoader(NavC.class.getResource("NavV.fxml"));
            Parent root = (Parent) loader.load();

            // - Scene
            Scene scene = new Scene(root);

            NavC navC = (NavC) loader.getController();
            navC.statement = statement;

            // - Stage
            if (stage == null) {
                stage = new Stage();
            }
            stage.setScene(scene);
            stage.setTitle("Navigation");

            user = (User) object;

            stage.show();
        } catch (IOException ex) {
            Logger.getLogger(RegisterC.class.getName()).log(Level.SEVERE, null, ex);
            System.err.println("Something wrong with NavV.fxml!");
            ex.printStackTrace(System.err);
            System.exit(1);
        }
    }

    @FXML
    private void btn1OnAction(ActionEvent event) {
        ViewController vC = new ViewController();
        vC.show(user, statement, getStage());
    }

    @FXML
    private void btn2OnAction(ActionEvent event) {
        ProfileC pC = new ProfileC();
        pC.show(user, statement, getStage());
    }

    @FXML
    private void btn3OnAction(ActionEvent event) throws SQLException, Exception {
        MealC mC = new MealC();
        mC.show(user, statement, getStage());
    }

    @FXML
    private void btn4OnAction(ActionEvent event) throws SQLException {
        PieChartController pChart = new PieChartController();
        pChart.show(user, statement, getStage());
    }

    public Stage getStage() {
        return (Stage) mainAnchorPane.getScene().getWindow();
    }

}
