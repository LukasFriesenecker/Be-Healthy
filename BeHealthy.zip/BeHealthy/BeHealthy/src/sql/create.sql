DROP TABLE users;

CREATE TABLE users(
  userID int PRIMARY KEY GENERATED ALWAYS AS IDENTITY(START WITH 1, INCREMENT BY 1),
  username varchar(30) NOT NULL,
  password varchar(25) NOT NULL,
  height decimal(3,2) NOT NULL,
  weight decimal(4,1) NOT NULL,
  age decimal(3) NOT NULL,
  weightaim varchar(1)
);

DROP TABLE valueInputs;

CREATE TABLE valueInputs(
    valueID int PRIMARY KEY GENERATED ALWAYS AS IDENTITY(START WITH 1, INCREMENT BY 1),
    userID int references users(userID),
    proteine decimal (3),
    kohlenhydrate decimal(3),
    fett decimal(3),
    zucker decimal(3),
    kcal decimal(4),
    currentTimeStamp timestamp,
    currentDay timestamp
); 

DROP TABLE weight;

CREATE TABLE weight(
    userID int,
    weight decimal(4,1),
    currentTimeStamp timestamp
);

DROP TABLE tipps;

CREATE TABLE tipps(
    username varchar(30),
    name varchar(30),
    type varchar(30),
    description varchar(500)
);

DROP TABLE meal;

CREATE TABLE meal(
    mealID int PRIMARY KEY GENERATED ALWAYS AS IDENTITY(START WITH 1, INCREMENT BY 1),
    username varchar(30),
    mealname varchar(30),
    ing1 decimal(3),
    ing2 decimal(3),
    ing3 decimal(3),
    ing4 decimal(3),
    ing5 decimal(4)
);