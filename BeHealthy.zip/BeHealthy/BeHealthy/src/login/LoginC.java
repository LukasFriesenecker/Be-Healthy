/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login;

import java.io.IOException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import nav.NavC;
import util.NullableNumberStringConverter;

/**
 *
 * @author Stefan
 */
public class LoginC {

    private Statement statement;

    @FXML
    private Button btnLogIn;
    @FXML
    private Button btnSignUp;
    @FXML
    private AnchorPane mainAnchorPane;

    private User model = new User();
    @FXML
    private TextField tfUsername;
    @FXML
    private PasswordField tfPassword;
    @FXML
    private Label loginError;
    @FXML
    private Label passwordError;
    @FXML
    private Label usernameError;

    @FXML
    private void btnLogInOnAction(ActionEvent event) {
        try {
            String[] error = model.login(statement);

            if (error[5] != null) {
                usernameError.setText(error[5]);
            } else {
                usernameError.setText("");

            }

            if (error[6] != null) {
                passwordError.setText(error[6]);
            } else {
                passwordError.setText("");
            }

            if (error[7] != null) {
                loginError.setText(error[7]);
            } else {
                loginError.setText("");

            }

            if (error[5] == null && error[6] == null && error[7] == null) {
                NavC nc = new NavC();
                nc.show(model, statement, getStage());
            }

            //Weiterleiten auf Startseite
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }

    @FXML
    private void btnSignUpOnAction(ActionEvent event) {
        RegisterC rC = new RegisterC();
        rC.show(getStage(), statement);
        Stage stage = (Stage) btnSignUp.getScene().getWindow();
    }

    public void show(Stage stage, Statement statement, Stage parent) {
        try {
            // View
            //  - Root
            FXMLLoader loader = new FXMLLoader(RegisterC.class.getResource("UserV.fxml"));
            Parent root = (Parent) loader.load();

            // - Scene
            Scene scene = new Scene(root);

            // - Stage
            if (stage == null) {
                stage = new Stage();
            }
            stage.setScene(scene);
            stage.setTitle("Login");

            // Controller
            LoginC userC = (LoginC) loader.getController();
            userC.statement = statement;

            // Model
            userC.model = new User();

            userC.getTfUsername().textProperty().bindBidirectional(userC.model.loginUsernameProperty());

            userC.getTfPassword().textProperty().bindBidirectional(userC.model.loginPasswordProperty());

            stage.show();
        } catch (IOException ex) {
            Logger.getLogger(RegisterC.class.getName()).log(Level.SEVERE, null, ex);
            System.err.println("Something wrong with PersonV.fxml!");
            ex.printStackTrace(System.err);
            System.exit(1);
        }
    }

    public TextField getTfUsername() {
        return tfUsername;
    }

    public void setTfUsername(TextField tfUsername) {
        this.tfUsername = tfUsername;
    }

    public PasswordField getTfPassword() {
        return tfPassword;
    }

    public void setTfPassword(PasswordField tfPassword) {
        this.tfPassword = tfPassword;
    }

    public Stage getStage() {
        return (Stage) mainAnchorPane.getScene().getWindow();
    }
}
