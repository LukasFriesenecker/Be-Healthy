/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login;

import java.io.IOException;
import java.net.URL;
import java.sql.Statement;
import java.text.NumberFormat;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import java.util.*;
import java.io.IOException;
import java.sql.Statement;
import java.text.NumberFormat;
import java.util.*;
import java.util.logging.*;
import javafx.event.ActionEvent;
import javafx.fxml.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.stage.*;
import java.text.NumberFormat;
import javafx.scene.layout.*;
import profile.ProfileC;
import util.NullableNumberStringConverter;

/**
 * FXML Controller class
 *
 * @author lukasfriesenecker / rafetseder tobias
 */
public class RegisterC {

    @FXML
    private Button btnLogIn;
    @FXML
    private Button btnSignUp;
    @FXML
    private TextField tfName;
    @FXML
    private PasswordField tfPassword;
    @FXML
    private TextField tfAge;
    @FXML
    private TextField tfHeight;
    @FXML
    private TextField tfWeight;
    private Statement statement;
    private AnchorPane rootPane;

    @FXML
    private AnchorPane mainAnchorPane;

    private User model;

    private static final NumberFormat DF;

    static {
        DF = NumberFormat.getNumberInstance();
        DF.setMaximumFractionDigits(2);
        DF.setMinimumFractionDigits(2);
    }
    @FXML
    private Label usernameError;
    @FXML
    private Label ageError;
    @FXML
    private Label heightError;
    @FXML
    private Label weightError;
    @FXML
    private Label passwordError;

    public RegisterC() {
    }

    @FXML
    private void btnLogInOnAction(ActionEvent event) {
        LoginC lc = new LoginC();
        lc.show(null, statement, getStage());
        Stage stage = (Stage) btnLogIn.getScene().getWindow();
        stage.close();
    }

    public void show(Stage stage, Statement statement) {
        try {
            // View
            //  - Root
            FXMLLoader loader = new FXMLLoader(RegisterC.class.getResource("Register.fxml"));
            Parent root = (Parent) loader.load();

            // - Scene
            Scene scene = new Scene(root);

            // - Stage
            if (stage == null) {
                stage = new Stage();
            }
            stage.setScene(scene);
            stage.setTitle("Register");

            // Controller
            RegisterC userC = (RegisterC) loader.getController();
            userC.statement = statement;

            // Model
            userC.model = new User();

            // Controller-Inits
            // Controls mit Model verbinden
            userC.getTfName().textProperty().bindBidirectional(userC.model.usernameProperty());

            userC.getTfPassword().textProperty().bindBidirectional(userC.model.passwordProperty());

            userC.getTfAge().textProperty().bindBidirectional(userC.model.ageProperty(), new NullableNumberStringConverter(DF));
            userC.getTfHeight().textProperty().bindBidirectional(userC.model.heightProperty(), new NullableNumberStringConverter(DF));
            userC.getTfWeight().textProperty().bindBidirectional(userC.model.weightProperty(), new NullableNumberStringConverter(DF));

            stage.show();
        } catch (IOException ex) {
            Logger.getLogger(RegisterC.class.getName()).log(Level.SEVERE, null, ex);
            System.err.println("Something wrong!");
            ex.printStackTrace(System.err);
            System.exit(1);
        }
    }

    public Button getBtnLogIn() {
        return btnLogIn;
    }

    public Button getBtnSignUp() {
        return btnSignUp;
    }

    public TextField getTfName() {
        return tfName;
    }

    public TextField getTfPassword() {
        return tfPassword;
    }

    public Statement getStatement() {
        return statement;
    }

    public TextField getTfAge() {
        return tfAge;
    }

    public TextField getTfHeight() {
        return tfHeight;
    }

    public TextField getTfWeight() {
        return tfWeight;
    }

    public User getModel() {
        return model;
    }

    public static NumberFormat getDf() {
        return DF;
    }

    public Stage getStage() {
        return (Stage) mainAnchorPane.getScene().getWindow();
    }

    @FXML
    private void btnSignUpOnAction(ActionEvent event) {
        try {
            String[] error = new User(model).save(statement);

            if (error[0] == null && error[1] == null && error[2] == null && error[3] == null && error[4] == null) {
                String name = tfName.getText();
                AimC aC = new AimC();
                aC.show(model, statement, getStage(), name);
            } else {
                usernameError.setText(error[0]);
                ageError.setText(error[4]);
                heightError.setText(error[2]);
                weightError.setText(error[3]);
                passwordError.setText(error[1]);
            }
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }

}
