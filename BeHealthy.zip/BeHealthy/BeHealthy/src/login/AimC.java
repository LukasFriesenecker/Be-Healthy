package login;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import profile.ProfileC;

public class AimC {

    private static String username;

    private Statement statement;

    private User user;
    @FXML
    private AnchorPane mainAnchorPane;
    @FXML
    private Button btn1;
    @FXML
    private Button btn3;
    @FXML
    private Button btn2;

    public void show(Object object, Statement statement, Stage stage, String name) {
        username = name;
        try {
            // View
            //  - Root

            FXMLLoader loader = new FXMLLoader(AimC.class.getResource("Aim.fxml"));

            Parent root = (Parent) loader.load();

            // - Scene
            Scene scene = new Scene(root);
            // - Stage
            if (stage == null) {
                stage = new Stage();
            }
            stage.setScene(scene);
            stage.setTitle("Aim");

            // Controller
            AimC valueC = (AimC) loader.getController();
            valueC.statement = statement;

            user = (User) object;

            stage.show();
        } catch (IOException ex) {
            Logger.getLogger(RegisterC.class.getName()).log(Level.SEVERE, null, ex);
            System.err.println("Something wrong");
            ex.printStackTrace(System.err);
            System.exit(1);
        }

    }

    @FXML
    private void btn1OnAction(ActionEvent event) throws SQLException {
        String sql = "update users set weightaim = 'L' where username = '" + username + "'";
        statement.executeUpdate(sql);
        LoginC lc = new LoginC();
        lc.show(null, statement, getStage());
        Stage stage = (Stage) btn1.getScene().getWindow();
        stage.close();
    }

    @FXML
    private void btn2OnAction(ActionEvent event) throws SQLException {
        String sql = "update users set weightaim = 'K' where username = '" + username + "'";
        statement.executeUpdate(sql);
        LoginC lc = new LoginC();
        lc.show(null, statement, getStage());
        Stage stage = (Stage) btn2.getScene().getWindow();
        stage.close();
    }

    @FXML
    private void btn3OnAction(ActionEvent event) throws SQLException {
        String sql = "update users set weightaim = 'G' where username = '" + username + "'";
        statement.executeUpdate(sql);
        LoginC lc = new LoginC();
        lc.show(null, statement, getStage());
        Stage stage = (Stage) btn3.getScene().getWindow();
        stage.close();
    }

    public Stage getStage() {
        return (Stage) mainAnchorPane.getScene().getWindow();
    }
}
