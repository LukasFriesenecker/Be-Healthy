package login;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javafx.application.Application;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *
 * @author ben
 */
public class Aim {

    private final StringProperty username = new SimpleStringProperty();


    public Aim() {
        clear();
    }

    public Aim(Aim u) {
        this.setUsername(u.getUsername());
    }

    public final void clear() {
        this.setUsername(null);

    }
    public void save(Statement statement) throws SQLException {
        String sql = "insert into users(weightaim) values('L') where username = username;";      
        statement.executeUpdate(sql);
    }
    
    // Setter und Getter: 
    public String getUsername() {
        return username.get();
    }

    public final void setUsername(String value) {
        username.set(value);
    }

}
