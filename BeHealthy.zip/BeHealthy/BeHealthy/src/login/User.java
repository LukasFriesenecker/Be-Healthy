package login;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.LocalDate;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author Tobias
 */
public class User {

    public String[] error = new String[8];

    private final StringProperty username = new SimpleStringProperty();
    private final StringProperty password = new SimpleStringProperty();
    private final ObjectProperty<Number> age = new SimpleObjectProperty<>();
    private final ObjectProperty<Number> weight = new SimpleObjectProperty<>();
    private final ObjectProperty<Number> height = new SimpleObjectProperty<>();

    // Login
    private final StringProperty loginUsername = new SimpleStringProperty();
    private final StringProperty loginPassword = new SimpleStringProperty();

    public User() {
        clear();
    }

    public User(User u) {
        this.setUsername(u.getUsername());
        this.setPassword(u.getPassword());
        this.setAge(u.getAge());
        this.setWeight(u.getWeight());
        this.setHeight(u.getHeight());

        // Login
        this.setLoginUsername(u.getLoginUsername());
        this.setLoginPassword(u.getLoginPassword());
    }

    public final void clear() {
        this.setUsername(null);
        this.setPassword(null);
        this.setAge(null);
        this.setWeight(null);
        this.setHeight(null);

        // Login
        this.setLoginUsername(null);
        this.setLoginPassword(null);
    }

    private void killAndFill() {
        // Username
        if (username.get() == null) {
            error[0] = "Please enter a valid username!";
        }

        if (username.get() != null && username.get().length() > 30) {
            error[0] = "Username can not be longer than 30 characters!";
        }

        if (username.get() != null && username.get().length() < 3) {
            error[0] = "Username must be 3 characters long!";
        }

        if (password.get() == null) {
            error[1] = "Please enter a valid password!";
        }

        // Height
        if (height.get() != null && (height.get().doubleValue() < 0.5 || height.get().doubleValue() > 3)) {
            error[2] = "Height must be in between 0.5m and 3m!";
        } else if (height.get() == null) {
            error[2] = "Please enter a valid height!";
        }

        // Weight
        if (weight.get() != null && (weight.get().doubleValue() < 20 || weight.get().doubleValue() > 300)) {
            error[3] = "Weight must be in between 20kg and 300kg!";
        } else if (weight.get() == null) {
            error[3] = "Please enter a valid weight!";
        }

        // Age
        if (age.get() != null && (age.get().doubleValue() < 6 || age.get().doubleValue() > 90)) {
            error[4] = "Age must be in between 6 and 90 years!";
        } else if (age.get() == null) {
            error[4] = "Please enter a valid age!";
        }
    }

    public String[] save(Statement statement) throws SQLException {
        killAndFill();

        if (error[0] == null && error[1] == null && error[2] == null && error[3] == null && error[4] == null) {
            String sql = "insert into users (username, password, age, height, weight) values('" + username.get() + "', '" + password.get() + "', " + age.get() + ", " + height.get() + ", " + weight.get() + ")";
            statement.executeUpdate(sql);

            int id = 0;
            String sqlSelect = "SELECT * FROM users WHERE username='" + username.get() + "'";
            ResultSet rsID = statement.executeQuery(sqlSelect);

            while (rsID.next()) {
                id = rsID.getInt("userID");
            }
            rsID.close();

            Timestamp timestamp = new Timestamp(System.currentTimeMillis());
            String insertWeight = "INSERT INTO weight(userID, weight, currentTimeStamp) VALUES (" + id + ", " + weight.get() + ", '" + timestamp + "')";
            statement.executeUpdate(insertWeight);
        }
        return error;
    }

    public void checkLoginInputs() {
        // Username
        if (loginUsername.get() == null) {
            error[5] = "Please enter your username!";
        } else {
            error[5] = null;
        }

        if (loginPassword.get() == null) {
            error[6] = "Please enter your passord!";
        } else {
            error[6] = null;
        }
    }

    // Login
    public String[] login(Statement statement) throws SQLException {
        checkLoginInputs();

        String checkLogin = "SELECT * FROM users WHERE username='" + loginUsername.get() + "' AND password='" + loginPassword.get() + "'";
        ResultSet rs = statement.executeQuery(checkLogin);

        if (rs.next()) {
            String username = rs.getString("username");

            Double height = rs.getDouble("height");
            Double age = rs.getDouble("age");
            Double weight = rs.getDouble("weight");

            this.setUsername(username);
            this.setHeight(height);
            this.setAge(age);
            this.setWeight(weight);
            error[7] = null;
        } else {
            error[7] = "Login-Data incrorrect!";
        }
        rs.close();
        return error;
    }

    // Setter und Getter: 
    public String getUsername() {
        return username.get();
    }

    public final void setUsername(String value) {
        username.set(value);
    }

    public Number getAge() {
        return age.get();
    }

    public final void setAge(Number value) {
        age.set(value);
    }

    public Number getWeight() {
        return weight.get();
    }

    public final void setWeight(Number value) {
        weight.set(value);
    }

    public Number getHeight() {
        return height.get();
    }

    public final void setHeight(Number value) {
        height.set(value);
    }

    public final void setPassword(String value) {
        password.set(value);
    }

    public String getPassword() {
        return password.get();
    }

    public StringProperty usernameProperty() {
        return username;
    }

    public StringProperty passwordProperty() {
        return password;
    }

    public ObjectProperty<Number> ageProperty() {
        return age;
    }

    public ObjectProperty<Number> heightProperty() {
        return height;
    }

    public ObjectProperty<Number> weightProperty() {
        return weight;
    }

    // Login
    public String getLoginUsername() {
        return loginUsername.get();
    }

    public final void setLoginUsername(String value) {
        loginUsername.set(value);
    }

    public final void setLoginPassword(String value) {
        loginPassword.set(value);
    }

    public String getLoginPassword() {
        return loginPassword.get();
    }

    public StringProperty loginUsernameProperty() {
        return loginUsername;
    }

    public StringProperty loginPasswordProperty() {
        return loginPassword;
    }
}
