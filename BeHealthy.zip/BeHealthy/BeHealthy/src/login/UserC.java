/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package login;

import java.io.IOException;
import java.net.URL;
import java.sql.Statement;
import java.text.NumberFormat;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import java.util.*;
import java.io.IOException;
import java.sql.Statement;
import java.text.NumberFormat;
import java.util.*;
import java.util.logging.*;
import javafx.event.ActionEvent;
import javafx.fxml.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.stage.*;
import java.text.NumberFormat;
import util.NullableNumberStringConverter;

/**
 * FXML Controller class
 *
 * @author lukasfriesenecker / rafetseder tobias / ben weinzierl
 */
public class UserC {

    @FXML
    private Button btnLogIn;
    @FXML
    private Button btnSignUp;
    @FXML
    private TextField tfName;
    private TextField tfPassword;
    private TextField tfAge;
    private TextField tfHeight;
    private TextField tfWeight;

    private Statement statement;
    

    private User model;

    private static final NumberFormat DF;

    static {
        DF = NumberFormat.getNumberInstance();
        DF.setMaximumFractionDigits(2);
        DF.setMinimumFractionDigits(2);
    }

    public UserC() {
    }

    @FXML
    private void btnLogInOnAction(ActionEvent event) {

    }

    

    public static void show(Stage stage, Statement statement) {
        try {
            // View
            //  - Root
            FXMLLoader loader = new FXMLLoader(UserC.class.getResource("Register.fxml"));
            Parent root = (Parent) loader.load();

            // - Scene
            Scene scene = new Scene(root);

            // - Stage
            if (stage == null) {
                stage = new Stage();
            }
            stage.setScene(scene);
            stage.setTitle("Login");

            // Controller
            UserC userC = (UserC) loader.getController();
            userC.statement = statement;

            // Model
            userC.model = new User();

            // Controller-Inits
            // Controls mit Model verbinden
            userC.getTfName().textProperty().bindBidirectional(userC.model.usernameProperty());
            userC.getTfPassword().textProperty().bindBidirectional(userC.model.passwordProperty());

            userC.getTfAge().textProperty().bindBidirectional(userC.model.ageProperty(), new NullableNumberStringConverter(DF));
            userC.getTfHeight().textProperty().bindBidirectional(userC.model.heightProperty(), new NullableNumberStringConverter(DF));
            userC.getTfWeight().textProperty().bindBidirectional(userC.model.weightProperty(), new NullableNumberStringConverter(DF));

            stage.show();
        } catch (IOException ex) {
            Logger.getLogger(UserC.class.getName()).log(Level.SEVERE, null, ex);
            System.err.println("Something wrong with PersonV.fxml!");
            ex.printStackTrace(System.err);
            System.exit(1);
        }
    }

    public Button getBtnLogIn() {
        return btnLogIn;
    }

    public Button getBtnSignUp() {
        return btnSignUp;
    }

    public TextField getTfName() {
        return tfName;
    }

    public TextField getTfPassword() {
        return tfPassword;
    }

    public Statement getStatement() {
        return statement;
    }

    public TextField getTfAge() {
        return tfAge;
    }

    public TextField getTfHeight() {
        return tfHeight;
    }

    public TextField getTfWeight() {
        return tfWeight;
    }

    public User getModel() {
        return model;
    }

    public static NumberFormat getDf() {
        return DF;
    }
    @FXML
    private void btnSignUpOnAction(ActionEvent event) {
        try {
            new User(model).save(statement);
            //model.clear();
            System.out.println("Button");
            //Weiterleiten auf Startseite
        } catch (Exception ex) {
            
            System.out.println("Bruh irgendwas is falsch " +  ex);
        }
    }
}
