/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perMealValues;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import java.text.NumberFormat;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.stage.Stage;
import login.LoginC;
import login.RegisterC;
import login.User;
import nav.NavC;
import util.NullableNumberStringConverter;

/**
 * FXML Controller class
 *
 * @author Tobias
 */
public class ViewController {

    @FXML
    private AnchorPane inputAnchorPane;
    @FXML
    private TextField tfProteine;
    @FXML
    private TextField tfKohlenhydrate;
    @FXML
    private TextField tfFett;
    @FXML
    private TextField tfKcal;
    @FXML
    private TextField tfZucker;
    @FXML
    private Button btnSave;
    private Statement statement;
    private Values model;
    private static User currentUser;
    private static final NumberFormat DF;

    static {
        DF = NumberFormat.getNumberInstance();
        DF.setMaximumFractionDigits(2);
        DF.setMinimumFractionDigits(2);
    }
    @FXML
    private Button backButton;
    @FXML
    private AnchorPane mainAnchorPane;
    @FXML
    private Button btnChooseMeal;
    @FXML
    private Label labelKohlenhydrate;
    @FXML
    private Label labelFett;
    @FXML
    private Label labelZucker;
    @FXML
    private Label labelKcal;
    @FXML
    private Label labelProteine;
    @FXML
    private ListView<String> mealSelect;
    @FXML
    private Button btnSubmit;
    @FXML
    private Button btnGoBack;
    private TextField tfMsg;
    private TextField tfUsername;
    @FXML
    private Label outputMsg;
    @FXML
    private Label username;
    private int proteine = 0;
    private int kohlenhydrate = 0;
    private int fett = 0;
    private int zucker = 0;
    private int kcal = 0;

    public void show(User u, Statement statement, Stage stage) {
        try {
            // View
            //  - Root

            FXMLLoader loader = new FXMLLoader(ViewController.class.getResource("View.fxml"));

            Parent root = (Parent) loader.load();
            // User currentUser = (User) object;

            // - Scene
            Scene scene = new Scene(root);

            // - Stage
            if (stage == null) {
                stage = new Stage();
            }
            stage.setScene(scene);
            stage.setTitle("Your daily values");

            // Controller
            ViewController valueC = (ViewController) loader.getController();
            valueC.statement = statement;

            // Model
            valueC.model = new Values();

            valueC.mealSelect.setVisible(false);
            valueC.btnGoBack.setVisible(false);
            valueC.btnSubmit.setVisible(false);
            stage.show();
            valueC.getTfProteine().textProperty().bindBidirectional(valueC.model.proteineProperty(), new NullableNumberStringConverter(DF));
            valueC.getTfKohlenhydrate().textProperty().bindBidirectional(valueC.model.kohlenhydrateProperty(), new NullableNumberStringConverter(DF));
            valueC.getTfFett().textProperty().bindBidirectional(valueC.model.fettProperty(), new NullableNumberStringConverter(DF));
            valueC.getTfZucker().textProperty().bindBidirectional(valueC.model.zuckerProperty(), new NullableNumberStringConverter(DF));
            valueC.getTfKcal().textProperty().bindBidirectional(valueC.model.kcalProperty(), new NullableNumberStringConverter(DF));

            currentUser = u;
            valueC.init(currentUser);

        } catch (IOException ex) {
            Logger.getLogger(RegisterC.class.getName()).log(Level.SEVERE, null, ex);
            System.err.println("Something wrong");
            ex.printStackTrace(System.err);
            System.exit(1);
        }
    }

    public TextField getTfProteine() {
        return tfProteine;
    }

    public TextField getTfKohlenhydrate() {
        return tfKohlenhydrate;
    }

    public TextField getTfFett() {
        return tfFett;
    }

    public TextField getTfZucker() {
        return tfZucker;
    }

    public TextField getTfKcal() {
        return tfKcal;
    }

    public static NumberFormat getDf() {
        return DF;
    }

    @FXML
    private void btnSaveOnAction(ActionEvent event) throws SQLException {
        new Values(model).save(statement, currentUser.getUsername(), outputMsg);
    }

    @FXML
    private void backToNav(ActionEvent event) {
        NavC nc = new NavC();
        nc.show(currentUser, statement, getStage());
    }

    public Stage getStage() {
        return (Stage) mainAnchorPane.getScene().getWindow();
    }

    @FXML
    private void btnChooseOnAction(ActionEvent event) throws SQLException {
        showListView();
    }

    @FXML
    private void btnSubmitOnAction(ActionEvent event) throws SQLException {
        showInputs();
        setValues();
    }

    @FXML
    private void btnGoBackOnAction(ActionEvent event) {
        showInputs();
    }

    public void showInputs() {
        getTfProteine().setVisible(true);
        getTfKohlenhydrate().setVisible(true);
        getTfZucker().setVisible(true);
        getTfFett().setVisible(true);
        getTfKcal().setVisible(true);
        labelProteine.setVisible(true);
        labelKohlenhydrate.setVisible(true);
        labelFett.setVisible(true);
        labelZucker.setVisible(true);
        labelKcal.setVisible(true);
        mealSelect.setVisible(false);
        btnGoBack.setVisible(false);
        btnSubmit.setVisible(false);
    }

    public void showListView() throws SQLException {
        getTfProteine().setVisible(false);
        getTfKohlenhydrate().setVisible(false);
        getTfZucker().setVisible(false);
        getTfFett().setVisible(false);
        getTfKcal().setVisible(false);
        labelProteine.setVisible(false);
        labelKohlenhydrate.setVisible(false);
        labelFett.setVisible(false);
        labelZucker.setVisible(false);
        labelKcal.setVisible(false);
        mealSelect.setVisible(true);
        btnGoBack.setVisible(true);
        btnSubmit.setVisible(true);
        initListView();
    }

    public void initListView() throws SQLException {
        String mealName;
        String sqlSelect = "SELECT * FROM meal WHERE username='" + currentUser.getUsername() + "'";
        ResultSet rs = statement.executeQuery(sqlSelect);
        mealSelect.getItems().clear();
        while (rs.next()) {
            mealName = rs.getString("mealname");
            mealSelect.getItems().addAll(mealName);
        }
        rs.close();
    }

    public void init(User user) {
        username.setText(user.getUsername());
    }

    public void setValues() throws SQLException {
        String mealname = mealSelect.getSelectionModel().getSelectedItem();
        String sql_proteine = "SELECT ing1 FROM meal WHERE username='" + currentUser.getUsername() + "'" + "AND mealname = " + "'" + mealname + "'";
        ResultSet rs = statement.executeQuery(sql_proteine);
        while (rs.next()) {
            proteine = rs.getInt("ing1");
        }
        getTfProteine().setText(proteine + "");

        String sql_kohlenhydrate = "SELECT ing2 FROM meal WHERE username='" + currentUser.getUsername() + "'" + "AND mealname = " + "'" + mealname + "'";
        rs = statement.executeQuery(sql_kohlenhydrate);
        while (rs.next()) {
            kohlenhydrate = rs.getInt("ing2");
        }
        getTfKohlenhydrate().setText(kohlenhydrate + "");

        String sql_fett = "SELECT ing3 FROM meal WHERE username='" + currentUser.getUsername() + "'" + "AND mealname = " + "'" + mealname + "'";
        rs = statement.executeQuery(sql_fett);
        while (rs.next()) {
            fett = rs.getInt("ing3");
        }
        getTfFett().setText(fett + "");

        String sql_zucker = "SELECT ing4 FROM meal WHERE username='" + currentUser.getUsername() + "'" + "AND mealname = " + "'" + mealname + "'";
        rs = statement.executeQuery(sql_zucker);
        while (rs.next()) {
            zucker = rs.getInt("ing4");
        }
        getTfZucker().setText(zucker + "");

        String sql_kcal = "SELECT ing5 FROM meal WHERE username='" + currentUser.getUsername() + "'" + "AND mealname = " + "'" + mealname + "'";
        rs = statement.executeQuery(sql_kcal);
        while (rs.next()) {
            kcal = rs.getInt("ing5");
        }
        getTfKcal().setText(kcal + "");

    }
}
