/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package perMealValues;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.LocalDate;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

/**
 *
 * @author Tobias
 */
public class Values {

    private final ObjectProperty<Number> proteine = new SimpleObjectProperty<>();
    private final ObjectProperty<Number> kohlenhydrate = new SimpleObjectProperty<>();
    private final ObjectProperty<Number> fett = new SimpleObjectProperty<>();
    private final ObjectProperty<Number> zucker = new SimpleObjectProperty<>();
    private final ObjectProperty<Number> kcal = new SimpleObjectProperty<>();
    boolean savable = true;

    public Values() {
        clear();
    }

    public Values(Values v) {
        this.setProteine(v.getProteine());
        this.setKohlenhydrate(v.getKohlenhydrate());
        this.setFett(v.getFett());
        this.setZucker(v.getZucker());
        this.setKcal(v.getKcal());
    }

    public final void clear() {
        this.setProteine(null);
        this.setKohlenhydrate(null);
        this.setFett(null);
        this.setZucker(null);
        this.setKcal(null);
    }

    public void checkInputs(Label tfMsg) {
        savable = true;
        // Proteine    
        if (proteine.get() != null
                && (proteine.get().doubleValue() < 1 || proteine.get().doubleValue() > 999)) {
            tfMsg.setText("The amount of proteins has to be between 1 and 999 ("
                    + proteine.get().doubleValue() + ")!");
            savable = false;
        } else if (proteine.get() == null) {
            tfMsg.setText("Please select the amount of proteins.");
            savable = false;
        }

        // Kohlenhydrate
        if (kohlenhydrate.get() != null
                && (kohlenhydrate.get().doubleValue() < 1 || kohlenhydrate.get().doubleValue() > 999)) {
            tfMsg.setText("The amount of carbohydrates has to be between 1 and 999 ("
                    + kohlenhydrate.get().doubleValue() + ")!");
            savable = false;
        } else if (kohlenhydrate.get() == null) {
            tfMsg.setText("Please select the amount of carbohydrates.");
            savable = false;
        }

        // fett
        if (fett.get() != null
                && (fett.get().doubleValue() < 1 || fett.get().doubleValue() > 999)) {
            tfMsg.setText("The amount of fat has to be between 1 and 999 ("
                    + fett.get().doubleValue() + ")!");
            savable = false;
        } else if (fett.get() == null) {
            tfMsg.setText("Please select the amount of fat.");
            savable = false;
        }

        // zucker
        if (zucker.get() != null
                && (zucker.get().doubleValue() < 1 || zucker.get().doubleValue() > 999)) {
            tfMsg.setText("The amount of sugar has to be between 1 and 999 ("
                    + zucker.get().doubleValue() + ")!");
            savable = false;
        } else if (zucker.get() == null) {
            tfMsg.setText("Please select the amount of sugar.");
            savable = false;
        }

        // kcal
        if (kcal.get() != null
                && (kcal.get().doubleValue() < 1 || kcal.get().doubleValue() > 9999)) {
            tfMsg.setText("The amount of kcal has to be between 1 and 9999 ("
                    + kcal.get().doubleValue() + ")!");
            savable = false;
        } else if (kcal.get() == null) {
            tfMsg.setText("Please select the amount of kcal.");
            savable = false;
        }
    }

    public void save(Statement statement, String username, Label tfMsg) throws SQLException {
        checkInputs(tfMsg);
        if (savable) {
            int id = 0;
            String sqlSelect = "SELECT * FROM users WHERE username='" + username + "'";
            ResultSet rs = statement.executeQuery(sqlSelect);

            while (rs.next()) {
                id = rs.getInt("userID");
            }
            rs.close();

            Timestamp time = new Timestamp(System.currentTimeMillis());
            Timestamp timestamp = new Timestamp(System.currentTimeMillis());
            timestamp.setMinutes(0);
            timestamp.setHours(0);
            timestamp.setNanos(0);
            timestamp.setSeconds(0);

            String sqlInsert = "insert into valueInputs (userID, proteine, kohlenhydrate, fett, zucker, kcal, currentTimeStamp, currentDay) values(" + id + ", " + proteine.get() + ", " + kohlenhydrate.get() + ", " + fett.get() + ", " + zucker.get() + ", " + kcal.get() + ", " + "'" + time + "', '" + timestamp + "')";
            statement.executeUpdate(sqlInsert);

            tfMsg.setText("Values saved!");
        }

    }

    //Setter und Getter
    public Number getProteine() {
        return proteine.get();
    }

    public final void setProteine(Number value) {
        proteine.set(value);
    }

    public Number getKohlenhydrate() {
        return kohlenhydrate.get();
    }

    public final void setKohlenhydrate(Number value) {
        kohlenhydrate.set(value);
    }

    public Number getFett() {
        return fett.get();
    }

    public final void setFett(Number value) {
        fett.set(value);
    }

    public Number getZucker() {
        return zucker.get();
    }

    public final void setZucker(Number value) {
        zucker.set(value);
    }

    public Number getKcal() {
        return kcal.get();
    }

    public final void setKcal(Number value) {
        kcal.set(value);
    }

    public ObjectProperty<Number> proteineProperty() {
        return proteine;
    }

    public ObjectProperty<Number> kohlenhydrateProperty() {
        return kohlenhydrate;
    }

    public ObjectProperty<Number> fettProperty() {
        return fett;
    }

    public ObjectProperty<Number> zuckerProperty() {
        return zucker;
    }

    public ObjectProperty<Number> kcalProperty() {
        return kcal;
    }

}
